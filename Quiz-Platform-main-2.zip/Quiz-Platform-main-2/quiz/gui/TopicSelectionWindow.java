package am.aua.quiz.gui;

import am.aua.quiz.core.QuizDatabase;
import am.aua.quiz.topics.Topic;

import javax.swing.*;
import java.util.stream.Collectors;

public class TopicSelectionWindow extends MultipleChoiceWindow {
    private QuizDatabase database;

    public TopicSelectionWindow(QuizDatabase database) {
        super("Select Topic");
        this.database = database;
        updateContent();
    }

    @Override
    protected void updateContent() {
        JPanel choicePanel = (JPanel) getContentPane().getComponent(0);  // Retrieve the choice panel
        choicePanel.removeAll();  // Clear previous content
        choiceGroup = new ButtonGroup();  // Reinitialize the button group for new content

        // Add radio buttons for each topic in the database
        for (Topic topic : database.getTopics()) {
            JRadioButton radioButton = new JRadioButton(topic.getName());
            radioButton.setActionCommand(topic.getName());  // Set action command to topic name for identification
            choiceGroup.add(radioButton);
            choicePanel.add(radioButton);
        }

        validate();
        repaint();

        if (selectButton.getActionListeners().length > 0)
            selectButton.removeActionListener(selectButton.getActionListeners()[0]);  // Remove old action listeners
        selectButton.addActionListener(e -> {
            String selectedTopicName = getSelectedChoice();
            Topic selectedTopic = database.getTopics().stream()
                    .filter(t -> t.getName().equals(selectedTopicName))
                    .findFirst()
                    .orElse(null);
            if (selectedTopic != null) {
                new QuizSelectionWindow(selectedTopic);
                dispose();  // Close the topic selection window after opening the quiz selection window
            }
        });
    }
}
