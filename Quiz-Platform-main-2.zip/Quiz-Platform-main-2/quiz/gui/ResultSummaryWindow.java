package am.aua.quiz.gui;

import javax.swing.*;
import java.awt.*;

public class ResultSummaryWindow extends JFrame {
    public ResultSummaryWindow(String quizName, int correctAnswers, int totalQuestions) {
        super("Quiz Completed: " + quizName);
        setSize(350, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(3, 1));

        JLabel resultLabel = new JLabel("Your Score: " + correctAnswers + "/" + totalQuestions);
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        add(resultLabel);

        JLabel percentageLabel = new JLabel("Percentage: " + (int) ((double) correctAnswers / totalQuestions * 100) + "%");
        percentageLabel.setHorizontalAlignment(JLabel.CENTER);
        add(percentageLabel);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton);

        setVisible(true);
    }
}
