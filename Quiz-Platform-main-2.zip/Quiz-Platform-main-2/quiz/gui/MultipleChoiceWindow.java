package am.aua.quiz.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public abstract class MultipleChoiceWindow extends JFrame {
    protected ButtonGroup choiceGroup;
    protected JButton selectButton;
    protected JPanel choicePanel;  // Panel for choices or input fields

    public MultipleChoiceWindow(String title) {
        super(title);
        initializeComponents();
    }

    private void initializeComponents() {
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = 1;  // Allocate most space to the content

        choicePanel = new JPanel();
        choicePanel.setLayout(new BoxLayout(choicePanel, BoxLayout.Y_AXIS));
        add(choicePanel, gbc);

        // Setup constraints for selectButton
        selectButton = new JButton("Select");
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.PAGE_END;
        gbc.weighty = 0;
        gbc.insets = new Insets(10, 10, 10, 10);  // Padding around the button
        add(selectButton, gbc);

        setVisible(true);
    }

    protected abstract void updateContent();

    protected String getSelectedChoice() {
        if (choiceGroup != null) {
            for (Enumeration<AbstractButton> buttons = choiceGroup.getElements(); buttons.hasMoreElements();) {
                AbstractButton button = buttons.nextElement();
                if (button.isSelected()) {
                    return button.getText();
                }
            }
        }
        return null;
    }
}
