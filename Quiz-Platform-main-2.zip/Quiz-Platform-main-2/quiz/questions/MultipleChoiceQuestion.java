package am.aua.quiz.questions;

import am.aua.quiz.cli.QuizConsole;
import am.aua.quiz.exceptions.InvalidAnswerException;

import java.util.ArrayList;
import java.util.List;

public class MultipleChoiceQuestion extends Question {
    public MultipleChoiceQuestion(String questionText, List<String> options, int correctOptionIndex) {
        super(questionText, options, correctOptionIndex);
    }

    @Override
    public boolean checkAnswer(String answer) throws InvalidAnswerException {
        char selectedOptionChar = answer.toUpperCase().charAt(0);
        int selectedOptionIndex = selectedOptionChar - 'A';
        if (selectedOptionIndex != correctOptionIndex) {
            throw new InvalidAnswerException("Incorrect answer");
        }
        return true;
    }

    @Override
    public void askQuestion() {
        super.askQuestion();
        for (String option : this.getOptions()) {
            QuizConsole.displayMessage(option);
        }
        printAnswerFormat();
    }

    @Override
    public String getAnswerFormat() {
        return "a/A";
    }

    @Override
    public String toString() {
        StringBuilder optionsString = new StringBuilder();
        for (int i = 0; i < getOptions().size(); i++) {
            optionsString.append((char) ('A' + i)).append(") ").append(getOptions().get(i)).append("\n");
        }
        return "Multiple choice question:\n" + super.toString() + "\nOptions:\n" + optionsString.toString();
    }
}
