package am.aua.quiz.exceptions;

public class MalformedDatabaseException extends Exception {
    public MalformedDatabaseException() {
    }

    public MalformedDatabaseException(String message) {
        super(message);
    }
}
