package am.aua.quiz.gui;

import am.aua.quiz.core.Quiz;
import am.aua.quiz.topics.Topic;

import javax.swing.*;

public class QuizSelectionWindow extends MultipleChoiceWindow {
    private Topic topic;

    public QuizSelectionWindow(Topic topic) {
        super("Select Quiz");
        this.topic = topic;
        updateContent();
    }

    @Override
    protected void updateContent() {
        JPanel choicePanel = (JPanel) getContentPane().getComponent(0);  // Retrieve the choice panel
        choicePanel.removeAll();  // Clear previous content
        choiceGroup = new ButtonGroup();  // Reinitialize the button group for new content

        // Add radio buttons for each quiz in the topic
        for (Quiz quiz : topic.getQuizList()) {
            JRadioButton radioButton = new JRadioButton(quiz.getName());
            radioButton.setActionCommand(quiz.getName());  // Set action command to quiz name for identification
            choiceGroup.add(radioButton);
            choicePanel.add(radioButton);
        }

        validate();
        repaint();

        if (selectButton.getActionListeners().length > 0)
            selectButton.removeActionListener(selectButton.getActionListeners()[0]);  // Remove old action listeners
        selectButton.addActionListener(e -> {
            String selectedQuizName = getSelectedChoice();
            Quiz selectedQuiz = topic.getQuizList().stream()
                    .filter(q -> q.getName().equals(selectedQuizName))
                    .findFirst()
                    .orElse(null);
            if (selectedQuiz != null) {
                new QuestionWindow(selectedQuiz);
                dispose();  // Close the quiz selection window after opening the question window
            }
        });
    }
}
