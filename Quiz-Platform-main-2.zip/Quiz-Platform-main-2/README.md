# Quiz-Platform

Welcome to Our Final Project (Quiz Platform)
This is a quiz platform were user can take a quiz of 4 different topics Geography, History, Movies and Sports in each topic there are 5 quizzes related to that topic each containing 5 questions. There are 3 types of questions: multiple choice questions, Yes/No questions and fill in the blank (type questions) questions. 
Everything works properly however there are some parts that will be modified in the future for example the usage of InvalidQuestionException will be improved in the future. Also we did not add interface because in this level in our code we did not find the proper place to add it but we have some ideas and until next milestone everything will be ready.


We used https://www.oracle.com/java/ as a source of information.
Thank you in advance!
Authors: Areg Sargsyan, Ani Musoyan, Ani Mkhitaryan
