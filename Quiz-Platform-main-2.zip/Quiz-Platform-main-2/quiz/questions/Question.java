package am.aua.quiz.questions;

import am.aua.quiz.cli.QuizConsole;
import am.aua.quiz.exceptions.InvalidAnswerException;

import java.util.ArrayList;
import java.util.List;

public abstract class Question {
    private String questionText;
    List<String> answerOptions;
    int correctOptionIndex;

    public Question(String questionText, List<String> answerOptions, int correctOptionIndex) {
        this.questionText = questionText;
        this.answerOptions = answerOptions;
        this.correctOptionIndex = correctOptionIndex;
    }

    public void askQuestion() {
        QuizConsole.displayMessage(questionText);
    }

    public abstract boolean checkAnswer(String answer) throws InvalidAnswerException;

    public abstract String getAnswerFormat();

    public String getQuestionText() {
        return questionText;
    }

    public List<String> getOptions() {
        return this.answerOptions;
    }

    public int getCorrectAnswer() {
        return 0;
    }

    public void printAnswerFormat() {
        QuizConsole.displayMessage("Answer format: " + getAnswerFormat() + " ");
    }
    @Override
    public String toString() {
        return "Question: " + questionText;
    }
}
