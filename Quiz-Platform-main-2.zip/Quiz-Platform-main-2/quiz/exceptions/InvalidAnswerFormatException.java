package am.aua.quiz.exceptions;

public class InvalidAnswerFormatException extends Exception{
    public InvalidAnswerFormatException() {
    }

    public InvalidAnswerFormatException(String message) {
        super(message);
    }
}
