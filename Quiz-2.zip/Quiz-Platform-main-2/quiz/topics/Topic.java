package am.aua.quiz.topics;

import am.aua.quiz.cli.QuizConsole;
import am.aua.quiz.core.Quiz;
import am.aua.quiz.core.QuizDatabase;
import am.aua.quiz.exceptions.InvalidQuestionException;

import java.util.*;

public interface Topic {
    void addQuiz(Quiz quiz);

    String getName();

    void selectQuiz();
}