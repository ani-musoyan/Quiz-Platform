package am.aua.quiz.gui;

import am.aua.quiz.core.Quiz;
import am.aua.quiz.questions.FillInTheBlankQuestion;
import am.aua.quiz.questions.MultipleChoiceQuestion;
import am.aua.quiz.questions.Question;
import am.aua.quiz.questions.YesNoQuestion;

import javax.swing.*;
import java.awt.*;

public class QuestionWindow extends MultipleChoiceWindow {
    private Quiz quiz;
    private int currentQuestionIndex = 0;
    private int correctAnswersCount = 0;
    private JTextField textField;  // For fill-in-the-blank questions
    private JLabel questionLabel;  // Label to display the question text

    public QuestionWindow(Quiz quiz) {
        super("Quiz: " + quiz.getName());
        this.quiz = quiz;
        this.textField = new JTextField(20);
        updateContent();
    }

    @Override
    protected void updateContent() {
        getContentPane().removeAll();  // Clear previous components
        choicePanel = new JPanel();
        choicePanel.setLayout(new BoxLayout(choicePanel, BoxLayout.Y_AXIS));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.weighty = 0;  // Make sure label doesn't take too much vertical space

        // Add question label
        Question question = quiz.getQuestions().get(currentQuestionIndex);
        questionLabel = new JLabel(question.getQuestionText(), JLabel.CENTER);
        getContentPane().add(questionLabel, gbc);

        gbc.gridy = 1;
        gbc.weighty = 1;  // Allow choicePanel to take more space

        // Add choicePanel which may contain radio buttons or text field
        if (question instanceof FillInTheBlankQuestion) {
            textField.setText("");
            choicePanel.add(textField);
        } else {
            choiceGroup = new ButtonGroup();
            for (String option : question.getOptions()) {
                JRadioButton radioButton = new JRadioButton(option);
                choiceGroup.add(radioButton);
                choicePanel.add(radioButton);
            }
        }

        getContentPane().add(choicePanel, gbc);

        // Reset and add select button
        gbc.gridy = 2;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.PAGE_END;
        selectButton = new JButton("Select");
        selectButton.addActionListener(e -> handleAnswer(question));
        getContentPane().add(selectButton, gbc);

        validate();
        repaint();
    }

    private void handleAnswer(Question question) {
        boolean isCorrect = false;
        if (question instanceof MultipleChoiceQuestion || question instanceof YesNoQuestion) {
            String selectedOption = getSelectedChoice();
            int selectedIndex = question.getOptions().indexOf(selectedOption);
            isCorrect = selectedIndex == question.getCorrectAnswer();
        } else if (question instanceof FillInTheBlankQuestion) {
            String userAnswer = textField.getText().trim();
            isCorrect = userAnswer.equalsIgnoreCase(question.getOptions().getFirst());
        }

        if (isCorrect) {
            correctAnswersCount++;
        }

        if (currentQuestionIndex < quiz.getQuestions().size() - 1) {
            currentQuestionIndex++;
            updateContent();
        } else {
            new ResultSummaryWindow(quiz.getName(), correctAnswersCount, quiz.getQuestions().size());
            dispose();
        }
    }
}
