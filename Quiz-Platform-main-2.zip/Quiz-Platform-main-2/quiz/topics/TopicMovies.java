package am.aua.quiz.topics;

import am.aua.quiz.cli.QuizConsole;
import am.aua.quiz.core.Quiz;

import java.util.ArrayList;
import java.util.Random;

public class TopicMovies implements Topic {
    public static final String name = "Movies";
    ArrayList<Quiz> quizList = new ArrayList<>();

    @Override
    public void addQuiz(Quiz quiz) {
        this.getQuizList().add(quiz);
    }

    public String getName() {
        return name;
    }

    @Override
    public void selectQuiz() {
        QuizConsole.displayMessage("Please select a quiz (1-" + quizList.size() + ") or enter 'random' for a random quiz:");
        for (int i = 0; i < quizList.size(); i++) {
            QuizConsole.displayMessage((i + 1) + ". " + quizList.get(i).getName());
        }

        String choice = QuizConsole.getUserInput();
        if (choice.equalsIgnoreCase("random")) {
            int randomIndex = new Random().nextInt(quizList.size());
            Quiz selectedQuiz = quizList.get(randomIndex);
            selectedQuiz.takeQuiz();
        } else {
            int quizIndex = Integer.parseInt(choice);
            if (quizIndex >= 1 && quizIndex <= quizList.size()) {
                Quiz selectedQuiz = quizList.get(quizIndex - 1);
                selectedQuiz.takeQuiz();
            } else {
                QuizConsole.displayMessage("Invalid choice. Please select a valid quiz.");
                selectQuiz();
            }
        }
    }

    public ArrayList<Quiz> getQuizList() {
        return quizList;
    }
}
