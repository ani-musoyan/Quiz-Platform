package am.aua.quiz.core;

import am.aua.quiz.cli.QuizConsole;
import am.aua.quiz.exceptions.InvalidQuestionException;
import am.aua.quiz.exceptions.MalformedDatabaseException;
import am.aua.quiz.exceptions.QuizNotFoundException;
import am.aua.quiz.gui.MultipleChoiceWindow;
import am.aua.quiz.gui.TopicSelectionWindow;
import am.aua.quiz.topics.Topic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QuizPlatform {
    private QuizDatabase quizDatabase;

    public QuizPlatform() throws InvalidQuestionException {
        try {
            quizDatabase = new QuizDatabase();
        } catch (IOException e) {
            throw new RuntimeException("Database file not found");
        } catch (MalformedDatabaseException e) {
            throw new RuntimeException("Database file is invalid");
        }
    }

    public void run() {
        QuizConsole.displayMessage("Welcome to the Quiz Platform!");

        //try {
            List<String> options = new ArrayList<>();
            for (Topic topic : quizDatabase.getTopics()) options.add(topic.getName());
            new TopicSelectionWindow(quizDatabase);
//            //selectTopic();
//        } catch (QuizNotFoundException e) {
//            QuizConsole.displayMessage(e.getMessage());
//        }

        //QuizConsole.displayMessage("Thank you for using the Quiz Platform!");
    }

    private void selectTopic() throws QuizNotFoundException {
        QuizConsole.displayMessage("Please select a topic:");
        for (int i = 0; i < quizDatabase.getTopics().size(); i++) {
            QuizConsole.displayMessage((i + 1) + ". " + quizDatabase.getTopics().get(i).getName());
        }
        int choice = QuizConsole.getUserChoice(1, quizDatabase.getTopics().size());
        Topic selectedTopic = quizDatabase.getTopics().get(choice - 1);
        selectedTopic.selectQuiz();
    }
}