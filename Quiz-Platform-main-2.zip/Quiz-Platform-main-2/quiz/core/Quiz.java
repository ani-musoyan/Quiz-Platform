package am.aua.quiz.core;

import am.aua.quiz.cli.QuizConsole;
import am.aua.quiz.exceptions.InvalidAnswerException;
import am.aua.quiz.exceptions.InvalidAnswerFormatException;
import am.aua.quiz.questions.FillInTheBlankQuestion;
import am.aua.quiz.questions.MultipleChoiceQuestion;
import am.aua.quiz.questions.Question;
import am.aua.quiz.questions.YesNoQuestion;
import am.aua.quiz.exceptions.InvalidQuestionException;

import java.util.ArrayList;

public class Quiz {
    private String name;
    private ArrayList<Question> questions = new ArrayList<>();

    public Quiz validateQuestions() throws InvalidQuestionException {
        if (this.questions == null) {
            throw new InvalidQuestionException("Question array cannot be null.");
        }
        for (Question question : this.questions) {
            if (question == null) {
                throw new InvalidQuestionException("A question object is null.");
            }
        }
        return this;
    }

    public Quiz() {

    }

    public Quiz setName(String name) {
        this.name = name;
        return this;
    }

    public ArrayList<Question> getQuestions() {
        return this.questions;
    }

    public Quiz setQuestions(ArrayList<Question> questions) {
        this.questions.addAll(questions);
        return this;
    }

    public String getName() {
        return name;
    }

    public void takeQuiz() {
        int score = 0;
        for (Question question : questions) {
            // Display the question using its overridden toString() method

            // Get user input
            boolean answerIsValid = false;
            while (!answerIsValid) {
                QuizConsole.displayMessage(question.toString());
                String answer = QuizConsole.getUserInput();
                try {
                    // Check if the answer is valid
                    answerIsValid = validateAnswer(question, answer);

                    // Check the answer
                    question.checkAnswer(answer);
                    QuizConsole.displayMessage("Correct!");
                    score++;
                } catch (InvalidAnswerException e) {
                    QuizConsole.displayMessage("Incorrect answer.");
                    answerIsValid = true;
                } catch (RuntimeException e) {
                    QuizConsole.displayMessage("Incorrect.");
                } catch (InvalidAnswerFormatException e) {
                    QuizConsole.displayMessage("Incorrect answer format! Please try again.");
                }
            }
        }
        // Display the quiz completion message along with the score
        QuizConsole.displayMessage("Quiz completed. Your score: " + score + "/" + questions.size());
    }

    private boolean validateAnswer(Question question, String answer) throws InvalidAnswerFormatException, InvalidAnswerException {
        if (question instanceof YesNoQuestion) {
            if (!answer.equalsIgnoreCase("yes") && !answer.equalsIgnoreCase("no")) {
                throw new InvalidAnswerFormatException("Invalid answer format.");
            } else return question.checkAnswer(answer);
        } else if (question instanceof MultipleChoiceQuestion) {
            answer = answer.toUpperCase();
            if (!answer.equals("A") && !answer.equals("B") && !answer.equals("C") && !answer.equals("D")) {
                throw new InvalidAnswerFormatException("Invalid answer format.");
            }
            return question.checkAnswer(answer);
        }
        return true;
    }
}