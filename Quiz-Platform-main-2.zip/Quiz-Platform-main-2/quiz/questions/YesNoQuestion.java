package am.aua.quiz.questions;

import am.aua.quiz.exceptions.InvalidAnswerException;

import java.util.ArrayList;
import java.util.List;

public class YesNoQuestion extends Question {
    public YesNoQuestion(String questionText, boolean correctAnswer) {
        super(questionText, List.of("Yes", "No"), correctAnswer ? 0 : 1);
    }

    @Override
    public boolean checkAnswer(String answer) throws InvalidAnswerException {
        if ((answer.equalsIgnoreCase("yes") && this.getCorrectAnswer() != 0) || (answer.equalsIgnoreCase("no") && this.getCorrectAnswer() != 1)) {
            throw new InvalidAnswerException("Incorrect answer");
        }
        return true;
    }

    @Override
    public String getAnswerFormat() {
        return "yes/YES or no/NO";
    }

    @Override
    public void askQuestion() {
        super.askQuestion();
        printAnswerFormat();
    }

    @Override
    public String toString() {
        return "Yes/no question: " + super.toString();
    }
}
